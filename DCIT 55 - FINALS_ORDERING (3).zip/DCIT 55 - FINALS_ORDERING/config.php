<?php

$conn = mysqli_connect('localhost','root','','db_orderingsystem') or die('connection failed');

?>